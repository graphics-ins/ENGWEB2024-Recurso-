var express = require('express');
var router = express.Router();
var Livro = require('../controllers/livro');

// GET /books:
// GET /books?charater=EEEE:
// GET /books?genre=AAA:
router.get('/books', function(req, res, next) {
    if(req.query.character){
        Livro.findByCharacter(req.query.character)
          .then(dados => res.jsonp(dados))
          .catch(erro => res.status(500).jsonp(erro));
    }
    else if(req.query.genre){
        Livro.findByGenre(req.query.genre)
          .then(dados => res.jsonp(dados))
          .catch(erro => res.status(500).jsonp(erro));
    }
    else if(req.query.authors._id){
      Livro.findByAuthor(req.query.authors._id)
        .then(dados => res.jsonp(dados))
        .catch(erro => res.status(500).jsonp(erro));
  }
    else{
      Livro.list()
        .then(dados => res.jsonp(dados))
        .catch(erro => res.status(500).jsonp(erro));
    }
});

// GET /books/:id
router.get('/books/:id', function(req, res, next) {
  Livro.findById(req.params.id)
    .then(dados => {
      res.jsonp(dados)})
    .catch(erro => res.status(500).jsonp(erro));
});

// GET /books/genres
router.get('/books/genres', function(req, res, next) {
    Livro.listGenres()
      .then(dados => res.jsonp(dados))
      .catch(erro => res.status(500).jsonp(erro));
  });

// GET /books/characters
router.get('/books/characters', function(req, res, next) {
    Livro.listCharacters()
      .then(dados => res.jsonp(dados))
      .catch(erro => res.status(500).jsonp(erro));
  });


// POST /books
router.post('/books', function(req, res, next) {
  Livro.insert(req.body)
    .then(dados => res.jsonp(dados))
    .catch(erro => res.status(500).jsonp(erro));
});

// DELETE /books/:id:
router.delete('/books/:id', function(req, res, next) {
  Livro.remove(req.params.id)
    .then(dados => res.jsonp(dados))
    .catch(erro => res.status(500).jsonp(erro));
});

// PUT /books/:id
router.put('/books/:id', function(req, res, next) {
  Livro.update(req.body)
    .then(dados => res.jsonp(dados))
    .catch(erro => res.status(500).jsonp(erro));
});


module.exports = router;