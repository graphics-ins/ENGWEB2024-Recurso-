var mongoose = require("mongoose");


var livroSchema = new mongoose.Schema({
        "title" : String,
        "series": String,
        "author": String,
        "rating": String,
        "description": String,
        "language": String,
        "isbn": String,
        "genres": [String],
        "characters": [String],
        "bookFormat": String,
        "edition": String,
        "pages": String,
        "publisher": String,
        "publishDate": Date,
        "firstPublishDate" : Date,
        "awards": [String],
        "numRatings": String,
        "ratingsByStars": [String],
        "likedPercent": String,
        "setting": [String],
        "coverImg": String,
        "bbeScore": String,
        "bbeVotes": String,
        "price": String,
        _id: String

});

module.exports = mongoose.model('livro', livroSchema);