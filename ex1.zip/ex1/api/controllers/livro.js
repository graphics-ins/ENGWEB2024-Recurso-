const Livro = require('../models/livro');

module.exports.list = () => {
    return Livro
        .find()
        .exec();
}

module.exports.findById = id => {
    return Livro
        .findOne({_id: id})
        .exec();
}

module.exports.findByCharacter = character => {
    return Livro
        .find({"characters": character})
        .exec();
}

module.exports.findByAuthor = author => {
    return Livro
        .find({"authors": author._id})
        .exec();
}

module.exports.findByGenre = tipo => {
    return Livro
        .find({"genres": tipo})
        .exec();
}

module.exports.listGenres = () => {
    return Livro
        .distinct("genres")
        .sort()
        .exec();
}

module.exports.listCharacters = () => {
    return Livro
        .distinct("characters")
        .sort()
        .exec();
}

module.exports.insert = livro => {
    return Livro.create(livro);
}

module.exports.update = livro => {
    return Livro.updateOne({_id: livro._id}, livro);
}

module.exports.remove = id => {
    return Livro.deleteOne({_id: id});
}