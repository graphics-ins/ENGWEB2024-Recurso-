var express = require('express');
var router = express.Router();
var axios = require('axios');

/* GET home page. */
router.get('/', function(req, res, next) {
  var date = new Date().toISOString().substring(0, 16);

  axios.get('http://localhost:17000/books')
    .then(dados => {
      res.render('livros',{livros: dados.data, d : date});
    })
    .catch(erro => {
      res.render('error', {error: erro})
    }); 
});

router.get('/:id', function(req, res, next) {
  var date = new Date().toISOString().substring(0, 16);

  axios.get('http://localhost:17000/books/' + req.params.id)
    .then(dados => {
      res.render('livro',{livro: dados.data, d : date});
    })
    .catch(erro => {
      res.render('error', {error: erro})
    });
});

router.get('/authors/:id', function(req, res) {
    var data = new Date().toISOString().substring(0, 16);
    axios.get('http://localhost:17000/books?authors=' + req.params.id)
      .then(dados => {
        var livros = dados.data; // Lista de livros do autor
  
        // Total de livros escritos pelo autor
        var totalLivros = livros.length;
  
        res.render('author', {
          livros: livros,
          totalLivros: totalLivros,
          d: data
        });
      })
      .catch(erro => {
        res.render('error', { error: erro });
      });
  });

module.exports = router;